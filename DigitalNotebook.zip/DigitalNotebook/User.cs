﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalNotebook
{
    public class User : Users
    {
        private string[] name;
        private int levels;
        private string password;
        private bool confirmedProfile = false;
        private bool admin = false;

        public string[] Name { 
            get
            { 
                return this.name; 
            }
        }
        public int Levels
        {
            get
            {
                return this.levels;
            }
            set
            {
                this.levels = value;
            }

        }
        public string Password
        {
            get
            {
                return this.password;
            }
            set
            {
                this.password = value;
            }

        }
        public bool ConfirmedProfile
        {
            get
            {
                return this.confirmedProfile;
            }
            set
            {
                this.confirmedProfile = value;
            }

        }
        public bool Admin
        {
            get
            {
                return this.admin;
            }
            set
            {
                this.admin = value;
            }

        }
        
        internal User(string[] Name, int Level, string Password)
        {
            name = Name;
            levels = Level;
            password = Password;
        }
        public Dictionary<User, notes<note>> addNote(string[] name, Dictionary<User, notes<note>> userNotes, string password)
        {
            Console.WriteLine("!!!!");
            bool nameFound = false;
            Console.WriteLine("Enter the title of this note:");
            string[] t = Console.ReadLine().Split().ToArray();
            Console.WriteLine("Enter the note:");
            string[] c = Console.ReadLine().Split().ToArray();
            Console.WriteLine("Enter the name of the creator:");
            string[] cr = Console.ReadLine().Split().ToArray();
           
            Console.Clear();
            Console.WriteLine("Enter the user password:");
            string p = Console.ReadLine();
            Console.Clear();
            foreach (var item in userNotes)
            {
                if (string.Join("", item.Key.Name) == string.Join("", name) && item.Key.Password == p && item.Key.ConfirmedProfile == true)
                {
                    if (password != "")
                    {
                        int l = item.Key.Levels;
                        note note = new note(t, c, cr, l,password);
                        userNotes[item.Key].Add(note);
                        nameFound = true;
                        return userNotes;
                    }
                    else
                    {
                        int l = item.Key.Levels;
                        note note = new note(t, c, cr, l);
                        userNotes[item.Key].Add(note);
                        nameFound = true;
                        return userNotes;
                    }
                }
            }
            if (nameFound == false)
            {
                Console.WriteLine("User not found");
            }
            return userNotes;
        }
        public void Print(User user) 
        {
            Console.WriteLine($"Name: {string.Join("",user.Name)}");
            Console.WriteLine($"Restriction level: {user.Levels}");
            Console.WriteLine($"Confirmed status: {user.ConfirmedProfile} and admin status:{user.Admin}");
        }
        
    }
}
