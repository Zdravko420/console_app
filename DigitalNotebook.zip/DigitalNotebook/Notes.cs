﻿using SimpleTreeNode;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace DigitalNotebook
{
    public class notes<note> : IEnumerable<note>
    {
        public note[] arr;
        private static int initialCapacity = 4;
        private int count;
        private string name;

        
        public int Count
        {
            get { return this.count; }
            private set { this.count = value; }
        }

        public notes()
        {
            this.arr = new note[initialCapacity];
            this.count = 0;
        }
        private void Shift(int index)
        {
            for (int i = index; i < arr.Length - 1; i++)

            {
                arr[i] = arr[i + 1];

            }
            arr[Count - 1] = default;

        }
        public void Add(note item)
        {
            if (Count == arr.Length)
            {
                Resize();
            }
            arr[Count] = item;
            Count++;
        }

        public void Insert(int index, note item)
        {
            if (Count == arr.Length)
            {
                Resize();
            }
            for (int i = arr.Length - 1; i > index; i--) 
            {
                arr[i] = arr[i - 1];
            }
        }
        public int IndexOf(note item)
        {
            for (int i = 0; i < Count; i++)
            {
                if (Equals(item, arr[i]))
                {
                    return i;

                }
                //   return (int)item;
            }
            return -1;
        }
        public bool Contains(object item)
        {
            for (int i = 0; i < Count; i++)
            {
                if (Equals(item, arr[i]))
                {
                    return true;

                }

            }
            return false;

        }
        public object Remove(int index)
        {
            if (index >= Count || index < 0)
            {
                Console.WriteLine("Invalid index: " + index);
            }
            object item = arr[index];
            arr[index] = default;
            Shift(1);
            Count--;

            if (Count <= arr.Length / 2)
            {
                Resize();
            }
            return item;
        }

        public int Remove(note item)
        {
            int index = IndexOf(item);
            if (index == -1)
            {
                return index;
            }
            Remove(index);
            return index;
        }


        private void Resize()
        {
            note[] copy = new note[arr.Length * 2];
            Array.Copy(arr, copy, arr.Length);
            arr = copy;
        }
        public IEnumerator<note> GetEnumerator()
        {
            for (int i = 0; i < count; i++)
            {
                //if (this.arr[i].GetType() == typeof(file))
                //{
                //    yield return new file(this.arr[i].ToString().Split(" "));
                //}
                //else if (this.arr[i].GetType() == typeof(folder<object>))
                //{

                //}
                yield return this.arr[i];
            }
        }

        IEnumerator<note> IEnumerable<note>.GetEnumerator() => this.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
