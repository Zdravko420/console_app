﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalNotebook
{
    class console
    {
        public static void start() 
        {
            Users allUsers = new Users();
            AdminPage adminPage = new AdminPage();
            User firstAdmin = adminPage.getFirstAdmin(allUsers);

            while (true)
            {
                Menu(allUsers,adminPage,firstAdmin);
            }
        }
        public static void Menu(Users allUsers, AdminPage admin, User firstAdmin)
        {
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Choose action:");
            Console.WriteLine();
            Console.WriteLine("1: Add new user");
            Console.WriteLine("2: Note to everyone");
            Console.WriteLine("3: Note to my level");
            Console.WriteLine("4: Note with password");
            Console.WriteLine("5: View my notes");
            Console.WriteLine("6: View notes on my level");
            Console.WriteLine("7: View note with password");
            //Console.WriteLine("8: Open filing menu");
            Console.WriteLine("8: Open admin menu");
            //Console.WriteLine("10: File a request to admins");
            Console.WriteLine();
            int number = int.Parse(Console.ReadLine());
            Console.Clear();



            if (number == 1)
            {
                User user = allUsers.AddUser();

            }
            else if (number == 2)
            {
                Console.WriteLine("Enter username: ");
                string[] name1 = Console.ReadLine().Split().ToArray();

                string empty = "";
                allUsers.userNotes = firstAdmin.addNote(name1, allUsers.userNotes, empty);

            }
            else if (number == 3)
            {
                Console.WriteLine("Enter username: ");
                string[] name2 = Console.ReadLine().Split().ToArray();

                string empty2 = "";
                allUsers.userNotes = firstAdmin.addNote(name2, allUsers.userNotes, empty2);
            }
            else if (number == 4)
            {
                Console.WriteLine("Enter username: ");
                string[] name3 = Console.ReadLine().Split().ToArray();
                Console.WriteLine("Enter your password(make sure noone is looking over your shoulder): ");
                string password = Console.ReadLine();



                allUsers.userNotes = firstAdmin.addNote(name3, allUsers.userNotes, password);

            }
            else if (number == 5)
            {
                Console.WriteLine("Enter username: ");
                string[] name4 = Console.ReadLine().Split().ToArray();
                Console.WriteLine("Enter your password(make sure noone is looking over your shoulder): ");
                string pass = Console.ReadLine();
                Console.WriteLine("!!!!!!");
                allUsers.getMyNotes(name4, pass, allUsers);

            }
            else if (number == 6)
            {
                Console.WriteLine("Enter username: ");
                string[] name5 = Console.ReadLine().Split().ToArray();
                Console.WriteLine("Enter your password(make sure noone is looking over your shoulder): ");
                string pass2 = Console.ReadLine();

                allUsers.getNotesFromLevel(name5, pass2, allUsers);

            }
            else if (number == 7)
            {
                Console.WriteLine("Enter username: ");
                string[] name6 = Console.ReadLine().Split().ToArray();
                Console.WriteLine("Enter your password(make sure noone is looking over your shoulder): ");
                string pass3 = Console.ReadLine();
                Console.WriteLine("Enter your note password(make sure noone is looking over your shoulder): ");
                string pass4 = Console.ReadLine();
                allUsers.getNotebyPassword(name6, pass3, allUsers, pass4);

            }
            else if (number == 8)
            {
                Console.WriteLine("Enter your admin username:");
                string[] name = Console.ReadLine().Split().ToArray();
                Console.WriteLine("Enter your password:");
                string passsword = Console.ReadLine();

                foreach (var item in admin.getAllAdmins(allUsers.userNotes))
                {


                    Console.WriteLine(string.Join("", item.Name) + " - " + string.Join("", name));
                    if (item.Name == name || item.Password == passsword)
                    {
                        if (item.Admin == true && item.ConfirmedProfile == true)
                        {
                            Console.WriteLine("Enter the username of the user you wish to edit");
                            string[] name7 = Console.ReadLine().Split().ToArray();
                            foreach (var target in allUsers.userNotes)
                            {
                                Console.WriteLine(string.Join("", target.Key.Name) + "-" + string.Join("", name7));
                                Console.ReadKey();
                                if (string.Join("", target.Key.Name) == string.Join("", name7)) 
                                {
                                    admin.adminMenu(allUsers, admin.getAllAdmins(allUsers.userNotes), target.Key, item);
                                }
                            }

                        }

                    }
                }


            }
            else
            {
                Console.WriteLine("Incorrect input");

            }











        }

    }
}
