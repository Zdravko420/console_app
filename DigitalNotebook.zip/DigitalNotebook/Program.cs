﻿using System;
using System.IO;
using System.Linq;

namespace DigitalNotebook 
{
    class Program
    {
        static void Main(string[] args)
        {
            console.start();
        }
       

    }
}
