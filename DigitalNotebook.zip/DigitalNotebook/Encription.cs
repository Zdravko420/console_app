﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalNotebook
{
    class Encription
    {
    }
}
