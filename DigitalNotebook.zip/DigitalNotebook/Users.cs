﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalNotebook
{
    public  class  Users
    {
        public Dictionary<User, notes<note>> userNotes;

        

        public Users() 
        {
            userNotes = new Dictionary<User, notes<note>>();
        }
        public  User  AddUser() 
        {
            Console.WriteLine("Enter your name (your profile will be registered with this name): ");
            string[] name = Console.ReadLine().Split().ToArray();
            Console.WriteLine("Enter the permission level of this profile: ");
            int level = int.Parse( Console.ReadLine());
            Console.WriteLine("Enter user password: ");
            string password = Console.ReadLine();
            Console.WriteLine("Wait for confirmation from an admin.");

            User u = new User(name,level,password);
            notes<note> n = new notes<note>();


            userNotes[u] = n;

            return u;
        }

        public void getMyNotes(string[] name, string password, Users allUsers) 
        {
            Console.WriteLine("!!!!!");
            foreach (var item in allUsers.userNotes)
            {
                if (string.Join(" ", item.Key.Name) == string.Join(" ", name))
                {
                    if (item.Key.Password == password)
                    {
                        foreach (var note in item.Value)
                        {
                            note.PrintNote();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Incorrect password!");
                    }
                }
                else
                {
                    Console.WriteLine("User doesn't exist!");
                }
            }
            
        }
        public void getNotesFromLevel(string[] name, string password, Users allUsers) 
        {
            int lvl = 0;
            foreach (var item in allUsers.userNotes)
            {

                if (string.Join(" ", item.Key.Name) == string.Join(" ", name))
                {
                    if (item.Key.Password == password)
                    {
                        lvl = item.Key.Levels;
                        foreach (var user in allUsers.userNotes)
                        {
                            foreach (var note in user.Value)
                            {
                                if (note.Level <= lvl)
                                {
                                    note.PrintNote();
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Incorrect password!");
                    }
                }
                else
                {
                    Console.WriteLine("User doesn't exist!");
                }

            }
            
        }
        public void getNotebyPassword(string[] name, string password, Users allUsers, string notePassword) 
        {
            foreach (var item in allUsers.userNotes)
            {

                if (string.Join(" ", item.Key.Name) == string.Join(" ", name))
                {
                    if (item.Key.Password == password)
                    {
                        
                        foreach (var user in allUsers.userNotes)
                        {
                            foreach (var note in user.Value)
                            {
                                if (note.Password == notePassword)
                                {
                                    note.PrintNote();
                                }
                                else
                                {
                                    Console.WriteLine("Incorrect password!"); 
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Incorrect password!");
                    }
                }
                else
                {
                    Console.WriteLine("User doesn't exist!");
                }

            }

        }

    }
}
