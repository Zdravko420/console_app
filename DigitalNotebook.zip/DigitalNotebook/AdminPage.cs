﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalNotebook
{
    class AdminPage
    {
       
        public List<User> getAllAdmins(Dictionary<User, notes<note>> userNotes)
        {
            List<User> admins = new List<User>();

            foreach (var user in userNotes)
            {
                if (user.Key.Admin)
                {
                    admins.Add(user.Key);
                }
            }

            return admins;
        }

        public Queue<string> log;

        public User getFirstAdmin(Users allUsers) 
        {
            User mainAdmin = allUsers.AddUser();
            mainAdmin.ConfirmedProfile = true;
            mainAdmin.Admin = true;
            return mainAdmin; 
            
        }


        public void end() 
        {
            Console.WriteLine("Close program  >:(");
            Environment.Exit(0);
        }
        public Users  adminMenu(Users allUsers,List<User> admins, User confirmy, User admin) 
        {
            if (correctAdmin(admin, allUsers))
            {


                Console.Clear();
                Console.WriteLine("1: Aprove user");
                Console.WriteLine("2: Add admin");
                Console.WriteLine("3: Remove user");
                Console.WriteLine("4: activity log");
                Console.WriteLine("5: See all users");
                Console.WriteLine("6: Export all files files");
                Console.WriteLine("7: Import files from previus session");
                Console.WriteLine("8: See requests");
                Console.WriteLine("9: Close program  >:(");

                int number = int.Parse(Console.ReadLine());

                switch (number)
                {
                    case 1:
                        confirmUsers(confirmy, allUsers, admin);
                        break;
                    case 2:
                        addAdmin(confirmy, allUsers, admin);
                        break;
                    case 3:
                        break;

                    case 4:
                        // code block
                        break;
                    case 5:
                        // code block
                        break;

                    case 6:
                        // code block
                        break;

                    case 7:
                        // code block
                        break;
                    case 8:

                        break;
                    case 9:
                        end();

                        break;
                    default:

                        // code block
                        break;
                }
                return allUsers;
            }
            else
            {
                Console.WriteLine("Incorect admin!");
                return allUsers;
            }
        }
        public bool correctAdmin(User admin,Users allUsers) 
        {
            bool isCorrect = false;
            foreach (var item in allUsers.userNotes)
            {
                if (item.Key.Admin == true)
                {
                    isCorrect = true;
                }
            }
            return isCorrect;
        }
        public User confirmUsers(User confirmy, Users allUsers, User admin) 
        {
            foreach (var item in allUsers.userNotes)
            {
                if (item.Key == admin)
                {
                    confirmy.ConfirmedProfile = true;

                    return confirmy;
                } 
            }
            Console.WriteLine("User not confirmed!");
            return confirmy;
        }
        public User addAdmin(User potential, Users allUsers, User admin)
        {
            foreach (var item in allUsers.userNotes)
            {
                if (item.Key == admin)
                {
                    potential.Admin = true;

                    return potential;
                }
            }
            Console.WriteLine("User not confirmed for admin role!");
            return potential;



        }
        
        

    }
}
