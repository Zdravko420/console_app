﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalNotebook
{
    public  class note 
    {
        private string[] title;
        public string[] Title
        { get { return this.title; } }

        private string[] content;
        public string[] Content 
        {
            get { return this.content;}
        }

        private string[] creator;
        public string[] Creator { get { return this.creator; } }

        private int level;
        public int Level { get { return this.level; } }

        private string password;
        public string Password { get { return this.password; } }



        public note(string[] title, string[] content, string[] creator, int level)
        {
            this.title = title;
            this.content = content;

            this.creator = creator;
        }
        public note(string[] title, string[] content, string[] creator, int level, string password) : this(title, content, creator, level) 
        {
            this.title = title;
            this.content = content;

            this.creator = creator;
            this.password = password;
        }
        public void PrintNote()
        {
            
            {
                Console.WriteLine($"{string.Join(' ', this.Creator)} notes:");
                Console.WriteLine($"{string.Join(' ', this.Title)}");
                foreach (string word in this.Content)
                {
                    if (word == "!line")
                    {
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.Write(word + " ");
                    }
                }
            }

        }
        public void PrintNoteWithPassword(string userPassword) 
        {
            if (userPassword == Password)
            {
                Console.WriteLine("Incorect password");
            }
            else
            {
                Console.WriteLine($"{string.Join(' ', this.Creator)} notes:");
                Console.WriteLine($"{string.Join(' ', this.Title)}");
                foreach (string word in this.Content)
                {
                    if (word == "!line")
                    {
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.Write(word + " ");
                    }
                }
            }
            
        }
    }
}
